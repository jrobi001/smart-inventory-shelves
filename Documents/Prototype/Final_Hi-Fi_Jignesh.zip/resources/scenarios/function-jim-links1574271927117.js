(function(window, undefined) {

  var jimLinks = {
    "11c190d9-965e-42b4-bbbe-cd79b4fcc990" : {
      "Button_1" : [
        "9e3e24e2-b419-4dfc-bdb1-a13a413f0e76"
      ],
      "Button_2" : [
        "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73"
      ]
    },
    "e22ee542-f5c2-49b2-8273-3ecb703ac683" : {
      "Button_1" : [
        "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73"
      ]
    },
    "9e3e24e2-b419-4dfc-bdb1-a13a413f0e76" : {
      "Button_1" : [
        "5a576918-555c-40e2-bb1b-0a979e7d4c7a"
      ],
      "Button_2" : [
        "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73"
      ]
    },
    "5a576918-555c-40e2-bb1b-0a979e7d4c7a" : {
      "Button_1" : [
        "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73"
      ]
    },
    "f7f0c0d3-546b-4ba3-b284-6232f8b29fee" : {
      "Button_1" : [
        "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73"
      ]
    },
    "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73" : {
      "Button_1" : [
        "11c190d9-965e-42b4-bbbe-cd79b4fcc990"
      ],
      "Button_2" : [
        "baa18504-982f-4e77-b8ad-151a886381cc"
      ],
      "Button_3" : [
        "e22ee542-f5c2-49b2-8273-3ecb703ac683"
      ]
    },
    "baa18504-982f-4e77-b8ad-151a886381cc" : {
      "Image_1" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_2" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_3" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_4" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_5" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_6" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_7" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Image_8" : [
        "f7f0c0d3-546b-4ba3-b284-6232f8b29fee"
      ],
      "Button_1" : [
        "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);