(function(window, undefined) {
  var dictionary = {
    "11c190d9-965e-42b4-bbbe-cd79b4fcc990": "Enter Item Details Page",
    "e22ee542-f5c2-49b2-8273-3ecb703ac683": "recent_alerts",
    "9e3e24e2-b419-4dfc-bdb1-a13a413f0e76": "Item Details",
    "5a576918-555c-40e2-bb1b-0a979e7d4c7a": "Item Added",
    "f7f0c0d3-546b-4ba3-b284-6232f8b29fee": "remove_item_success",
    "db11b75e-b0e1-4ee1-906f-f18dfbdf8c73": "Home",
    "baa18504-982f-4e77-b8ad-151a886381cc": "Remove Item List",
    "ee9023a8-5f66-40e1-9a9a-f03729c26d74": "960 grid - 16 columns",
    "c8db0fee-f1a0-4bc2-bfd0-a1bc9a9c0ccd": "960 grid - 12 columns",
    "5f775701-9a6a-45dd-9c70-2e65c6a905f4": "Template 1",
    "30dcdef8-8e35-4ace-b645-0bad9ce17ac0": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);